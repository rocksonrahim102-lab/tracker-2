
import { useEffect, useState } from "react";
import API from "../services/api";

function ProjectList() {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    API.get("/projects")
      .then(res => setProjects(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div>
      <h2>Projects</h2>
      {projects.map((p) => (
        <div key={p.id}>{p.title}</div>
      ))}
    </div>
  );
}

export default ProjectList;
