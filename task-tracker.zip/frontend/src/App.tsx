
import ProjectList from "./components/ProjectList";

function App() {
  return (
    <div>
      <h1>Task Tracker</h1>
      <ProjectList />
    </div>
  );
}

export default App;
