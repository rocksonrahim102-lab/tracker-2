
import express from "express";
import { createTask, getTasks, updateTaskStatus } from "../controllers/task.controller";

const router = express.Router();
router.post("/", createTask);
router.get("/", getTasks);
router.patch("/:id/status", updateTaskStatus);

export default router;
