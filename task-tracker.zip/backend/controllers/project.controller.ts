
export const createProject = async (req, res) => {
  try {
    const { title } = req.body;
    if (!title) return res.status(400).json({ message: "Title required" });

    const project = { id: Date.now(), title };
    res.status(201).json(project);
  } catch {
    res.status(500).json({ message: "Server error" });
  }
};

export const getProjects = async (req, res) => {
  res.json([]);
};
