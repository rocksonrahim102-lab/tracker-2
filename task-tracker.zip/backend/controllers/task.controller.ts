
let tasks = [];

export const createTask = (req, res) => {
  const { title, status } = req.body;
  const task = { id: Date.now(), title, status: status || "To Do" };
  tasks.push(task);
  res.status(201).json(task);
};

export const getTasks = (req, res) => {
  res.json(tasks);
};

export const updateTaskStatus = (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const task = tasks.find(t => t.id == id);
  if (!task) return res.status(404).json({ message: "Task not found" });

  task.status = status;
  res.json(task);
};
